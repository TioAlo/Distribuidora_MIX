const mapaConfig = {
    "bebidas": {
        marcas: ["Ambev", "Heineken", "Coca-Cola", "PepsiCo", "Red Bull", "Minalba", "Indaiá", "Campari"],
        label: "Volume (Litragem)",
        unidades: ["ml", "L"]
    },
    "confeitaria": {
        marcas: ["Nestlé", "Lacta", "Ferrero", "Arcor", "Mondelez", "Garoto", "Hershey's", "Bauducco"],
        label: "Peso Líquido",
        unidades: ["g", "Kg"]
    },
    "descartaveis": {
        marcas: ["Copobras", "Prafesta", "TotalPack", "Plastilânia", "Sanremo", "Melitta"],
        label: "Qtd p/ Pacote",
        unidades: ["Un", "Pct", "Cx", "Fardo"]
    }
};

function configurarCampos() {
    const tipo = document.getElementById("tipoProduto").value;
    const selectMarca = document.getElementById("marca");
    const labelMedida = document.getElementById("labelMedida");
    const selectUnidade = document.getElementById("unidadeMedida");

    // Resetar campos
    selectMarca.innerHTML = '<option value="">Selecione...</option>';
    selectUnidade.innerHTML = '<option value="">---</option>';

    if (tipo && mapaConfig[tipo]) {
        const config = mapaConfig[tipo];
        
        // Habilitar e preencher Marcas
        selectMarca.disabled = false;
        config.marcas.forEach(m => {
            let opt = document.createElement("option");
            opt.value = m.toLowerCase();
            opt.text = m;
            selectMarca.add(opt);
        });

        // Atualizar Texto da Medida (Peso ou Litro)
        labelMedida.innerText = config.label;

        // Preencher Unidades de Medida
        config.unidades.forEach(u => {
            let opt = document.createElement("option");
            opt.value = u.toLowerCase();
            opt.text = u;
            selectUnidade.add(opt);
        });
    } else {
        selectMarca.disabled = true;
        labelMedida.innerText = "Medida";
    }
}

function gerarPreview(event) {
    const preview = document.getElementById('img-preview');
    const file = event.target.files[0];
    if (file) {
        preview.src = URL.createObjectURL(file);
        preview.style.display = 'inline-block';
    }
}