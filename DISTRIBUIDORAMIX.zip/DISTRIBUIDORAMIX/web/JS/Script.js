/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

// ------------------------------ INDEX ----------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    const mobileMenu = document.getElementById('mobile-menu');
    const navList = document.getElementById('nav-list');

    // Verifica se os elementos existem antes de adicionar o evento
    if (mobileMenu && navList) {
        mobileMenu.addEventListener('click', () => {
            // Alterna a classe 'active' para mostrar/esconder o menu
            navList.classList.toggle('active');

            // Opcional: Animação visual nas barras do hambúrguer
            mobileMenu.classList.toggle('is-active');
        });
    }
});


//CATALOGO
function filterBy(slug) {
    // Evita que o clique no link de subcategoria "suba" para a categoria pai
    if (event) event.stopPropagation();
    
    console.log("Filtrando catálogo para: " + slug);
    
    // Feedback visual
    const grid = document.querySelector('.products-grid');
    if(grid) {
        grid.style.opacity = "0.3";
        setTimeout(() => grid.style.opacity = "1", 400);
    }

    // Aqui você enviaria o 'slug' para o seu Banco de Dados via URL ou AJAX
    // Exemplo: window.location.href = "produtos.jsp?cat=" + slug;
}
function filterBy(slug) {
    // Evita que o clique no link de subcategoria "suba" para a categoria pai
    if (event) event.stopPropagation();
    
    console.log("Filtrando catálogo para: " + slug);
    
    // Feedback visual
    const grid = document.querySelector('.products-grid');
    if(grid) {
        grid.style.opacity = "0.3";
        setTimeout(() => grid.style.opacity = "1", 400);
    }

    // Aqui você enviaria o 'slug' para o seu Banco de Dados via URL ou AJAX
    // Exemplo: window.location.href = "produtos.jsp?cat=" + slug;
}




// Abre e fecha os filtros laterais
function toggleFilter(element) {
    const group = element.parentElement;
    group.classList.toggle('active');
}

// Filtro imediato (simulação de carregamento)
function filterBy(category) {
    const productList = document.getElementById('product-list');
    productList.style.opacity = "0.3";

    console.log("Filtrando catálogo por: " + category);

    // Simula tempo de resposta do servidor
    setTimeout(() => {
        productList.style.opacity = "1";
    }, 400);
}

//----------------------------------------------------------------------------------------

//----------------------------- LOGIN -----------------------------------------------------

//ocultador de cpf
const cpfInput = document.getElementById('cpf');
cpfInput.addEventListener('input', function (e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11)
        value = value.slice(0, 11);
    value = value.replace(/(\+d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    e.target.value = value;
});

//----------------------------------------------------------------------------------------

//----------------------------- CADASTRO -----------------------------------------------------
// Máscara de CPF
const cpfInput = document.getElementById('cpf');
cpfInput.addEventListener('input', function (e) {
    let v = e.target.value.replace(/\D/g, '');
    if (v.length > 11)
        v = v.slice(0, 11);
    v = v.replace(/(\d{3})(\d)/, "$1.$2");
    v = v.replace(/(\d{3})(\d)/, "$1.$2");
    v = v.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    e.target.value = v;
});

// Máscara de Telefone
const telInput = document.getElementById('telefone');
telInput.addEventListener('input', function (e) {
    let v = e.target.value.replace(/\D/g, '');
    v = v.replace(/^(\d{2})(\d)/g, "($1) $2");
    v = v.replace(/(\d{5})(\d)/, "$1-$2");
    e.target.value = v.slice(0, 15);
});

//----------------------------------------------------------------------------------------

//------------------ INSERIR PRODUTOS ----------------------------------------


// Função para mostrar a foto antes de enviar
function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function () {
        const output = document.getElementById('img-preview');
        output.src = reader.result;
        output.style.display = 'inline-block';
    };
    reader.readAsDataURL(event.target.files[0]);
}