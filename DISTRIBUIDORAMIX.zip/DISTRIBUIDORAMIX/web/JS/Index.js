/**
 * PROJETO: Distribuidora Mix
 * ARQUIVO: JavaScript.js
 * DESCRIÇÃO: Controle de filtros em cascata, ordenação via URL e animação do carrossel.
 */

// ==========================================================================
// 1. INICIALIZAÇÃO
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
    // Inicialização do carrossel
    initCarousel();
});

// ==========================================================================
// 2. LÓGICA DE FILTROS (CASCATA E URL)
// ==========================================================================

/**
 * Filtra os produtos recarregando a página com parâmetros na URL
 */
function filterBy(nivel, valor) {
    const url = new URL(window.location.href);
    if (nivel === 'todos') {
        url.searchParams.delete('nivel');
        url.searchParams.delete('valor');
    } else {
        url.searchParams.set('nivel', nivel);
        url.searchParams.set('valor', valor);
    }
    window.location.href = url.toString();
}

/**
 * Ordena os produtos (Preço, Nome, etc) via Query String
 */
function sortBy(ordem) {
    const url = new URL(window.location.href);
    if (ordem) {
        url.searchParams.set('ordem', ordem);
    } else {
        url.searchParams.delete('ordem');
    }
    window.location.href = url.toString();
}

/**
 * Expande/Recolhe os subníveis do menu lateral (Tipo > Subtipo > Marca)
 */
function toggleFilter(btn) {
    // O submenu é o próximo elemento irmão do contêiner do botão
    const parentHeader = btn.parentElement;
    const submenu = parentHeader.nextElementSibling;
    
    if (submenu && submenu.classList.contains('submenu')) {
        submenu.classList.toggle('active');
        // Altera o ícone visual entre '>' e 'v'
        btn.textContent = submenu.classList.contains('active') ? 'v' : '>';
        
        // Adiciona classe ao pai para controle de rotação via CSS (opcional)
        parentHeader.parentElement.classList.toggle('active');
    }
}

// ==========================================================================
// 3. LÓGICA DO CARROSSEL (AUTO-SCROLL)
// ==========================================================================
function initCarousel() {
    const track = document.querySelector('.carousel-track');
    let isPaused = false;

    if (track) {
        setInterval(() => {
            if (!isPaused) {
                track.scrollLeft += 1;
                // Reinicia o scroll ao chegar no fim
                if (track.scrollLeft >= (track.scrollWidth - track.clientWidth)) {
                    track.scrollLeft = 0;
                }
            }
        }, 30);

        // Pausa ao passar o mouse
        track.addEventListener('mouseenter', () => isPaused = true);
        track.addEventListener('mouseleave', () => isPaused = false);
    }
}

// ==========================================================================
// 4. MODAL DE QUANTIDADE (INTERFACE SIMPLES)
// ==========================================================================
// Nota: Se você removeu o carrinho, estas funções podem ser mantidas 
// apenas se você ainda pretende usar o modal para outra ação futura.

// 1. Definição Global (Deve ser a primeira linha do arquivo)
var cart = JSON.parse(localStorage.getItem('distribuidora_cart')) || [];
var currentProduct = null;

// Garante que o contador atualize assim que a página carregar
document.addEventListener('DOMContentLoaded', () => {
    if (typeof initCarousel === "function") initCarousel();
    renderCart(); 
});

// 2. Lógica do Modal de Quantidade
function openQtyModal(name, price, id) {
    currentProduct = { id: id, name: name, price: parseFloat(price) };
    
    const nameElem = document.getElementById('modal-product-name');
    const modal = document.getElementById('modal-qty');
    
    if (nameElem && modal) {
        nameElem.innerText = name;
        modal.style.display = 'flex'; // Abre o modal
    }
}

function closeModalQty() {
    const modal = document.getElementById('modal-qty');
    if (modal) modal.style.display = 'none';
}

// 3. Adicionar ao Carrinho (A função que estava dando erro)
function confirmAdd() {
    const qtyInput = document.getElementById('input-qty');
    const qty = parseInt(qtyInput.value);

    if (!qty || qty <= 0) {
        alert("Insira uma quantidade válida.");
        return;
    }

    // Procura se já existe para somar
    const index = cart.findIndex(item => item.id === currentProduct.id);

    if (index > -1) {
        cart[index].quantity += qty;
    } else {
        cart.push({
            id: currentProduct.id,
            name: currentProduct.name,
            price: currentProduct.price,
            quantity: qty
        });
    }

    localStorage.setItem('distribuidora_cart', JSON.stringify(cart));
    renderCart(); // Atualiza a tela
    closeModalQty(); // Fecha o popup de quantidade
}

// 4. Renderizar o Popup do Carrinho
function renderCart() {
    const itemsCont = document.getElementById('cart-items');
    const countBadge = document.getElementById('cart-count');
    const totalElem = document.getElementById('cart-total');

    // Atualiza a bolinha laranja
    const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
    if (countBadge) countBadge.innerText = totalItems;

    if (!itemsCont) return;

    itemsCont.innerHTML = "";
    let totalMoney = 0;

    cart.forEach(item => {
        const sub = item.price * item.quantity;
        totalMoney += sub;

        itemsCont.innerHTML += `
            <tr>
                <td style="text-align:left"><b>${item.name}</b></td>
                <td>${item.quantity}</td>
                <td>R$ ${sub.toFixed(2).replace('.',',')}</td>
                <td><button class="remove-item" onclick="removeItem(${item.id})">&times;</button></td>
            </tr>
        `;
    });

    if (totalElem) totalElem.innerText = `R$ ${totalMoney.toFixed(2).replace('.',',')}`;
}

function removeItem(id) {
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem('distribuidora_cart', JSON.stringify(cart));
    renderCart();
}

function toggleCart() {
    const modal = document.getElementById('cart-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'flex') ? 'none' : 'flex';
    }
}

function checkout() {
    const fone = "5532988429002"; 
    if (cart.length === 0) return alert("Carrinho vazio!");

    let msg = "*Pedido Distribuidora Mix*\n\n";
    cart.forEach(i => msg += `• ${i.quantity}x ${i.name} - R$ ${(i.price*i.quantity).toFixed(2).replace('.',',')}\n`);
    msg += `\n*Total: ${document.getElementById('cart-total').innerText}*`;
    
    window.open(`https://wa.me/${fone}?text=${encodeURIComponent(msg)}`, '_blank');
}