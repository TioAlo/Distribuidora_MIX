package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/InserirProdutoServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class InserirProdutoServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            // 1. Captura os dados do formulário
            String nome = request.getParameter("nome");
            String tipo = request.getParameter("tipoProduto");
            String marca = request.getParameter("marca");
            double preco = Double.parseDouble(request.getParameter("preco"));
            double valorMedida = Double.parseDouble(request.getParameter("valorMedida"));
            String unidadeMedida = request.getParameter("unidadeMedida");
            int estoque = Integer.parseInt(request.getParameter("estoque"));
            String descricao = request.getParameter("descricao");
            boolean destaque = request.getParameter("destaque") != null;

            // 2. Processa a Imagem
            Part filePart = request.getPart("imagem");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            
            // Define o caminho real da pasta 'images' no servidor
            String uploadPath = getServletContext().getRealPath("") + File.separator + "images";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();
            
            filePart.write(uploadPath + File.separator + fileName);

            // 3. Conexão e Inserção no MySQL (Substitua pelos seus dados)
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");
            
            String sql = "INSERT INTO produtos (nome, tipo_produto, marca, preco, valor_medida, unidade_medida, estoque, descricao, imagem, destaque) VALUES (?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nome);
            ps.setString(2, tipo);
            ps.setString(3, marca);
            ps.setDouble(4, preco);
            ps.setDouble(5, valorMedida);
            ps.setString(6, unidadeMedida);
            ps.setInt(7, estoque);
            ps.setString(8, descricao);
            ps.setString(9, fileName);
            ps.setBoolean(10, destaque);
            
            ps.executeUpdate();
            conn.close();

            response.sendRedirect("JSP/InserirProdutos.jsp?msg=sucesso");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("JSP/InserirProdutos.jsp?msg=erro");
        }
    }
}