package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/InserirProdutoServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, 
    maxFileSize = 1024 * 1024 * 10,      
    maxRequestSize = 1024 * 1024 * 50    
)
public class InserirProdutoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            // 1. Captura de dados (Nomes dos parâmetros do seu JSP)
            String nome = request.getParameter("nome");
            String tipoProduto = request.getParameter("tipoProduto"); // Vem do select de departamento
            String subtipo = request.getParameter("subtipo"); 
            String marca = request.getParameter("marca");
            double preco = Double.parseDouble(request.getParameter("preco"));
            double valorMedida = Double.parseDouble(request.getParameter("valorMedida"));
            String unidadeMedida = request.getParameter("unidadeMedida");
            int estoque = Integer.parseInt(request.getParameter("estoque"));
            String descricao = request.getParameter("descricao");
            boolean destaque = request.getParameter("destaque") != null;

            // 2. Processamento da Imagem
            Part filePart = request.getPart("imagem");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            
            // Caminho para salvar (conforme sua estrutura de pastas)
            String uploadPath = "C:\\Users\\975009\\Documents\\NetBeansProjects\\DISTRIBUIDORAMIX\\web\\Assets\\ProdutosInseridos"; 
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();
            
            filePart.write(uploadPath + File.separator + fileName);

            // 3. Inserção no Banco de Dados (Ajustado para os nomes na sua imagem)
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");
            
            // Query corrigida: 'tipo_produto' e 'descricao' (sem til, conforme sua imagem do Workbench)
            String sql = "INSERT INTO produtos (nome, tipo_produto, subtipo, marca, preco, valor_medida, unidade_medida, estoque, descricao, imagem, destaque) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nome);
            ps.setString(2, tipoProduto);
            ps.setString(3, subtipo); 
            ps.setString(4, marca);
            ps.setDouble(5, preco);   
            ps.setDouble(6, valorMedida);
            ps.setString(7, unidadeMedida);
            ps.setInt(8, estoque);
            ps.setString(9, descricao);
            ps.setString(10, fileName);
            ps.setBoolean(11, destaque); 
            
            ps.executeUpdate();
            
            ps.close();
            conn.close();

            response.sendRedirect("JSP/CadastrarProduto.jsp?msg=sucesso");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("JSP/CadastrarProduto.jsp?msg=erro");
        }
    }
}