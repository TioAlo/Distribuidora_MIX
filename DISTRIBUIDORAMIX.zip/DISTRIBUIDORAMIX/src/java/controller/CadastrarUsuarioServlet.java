package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CadastrarUsuarioServlet")
public class CadastrarUsuarioServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            // 1. Captura de dados
            String nome = request.getParameter("nome");
            String cpf = request.getParameter("cpf");
            String telefone = request.getParameter("telefone");
            String email = request.getParameter("email");
            String rua = request.getParameter("rua");
            String numero = request.getParameter("numero");
            String bairro = request.getParameter("bairro");
            String senha = request.getParameter("senha");

            // 2. Conexão com o Banco
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");

            // 3. SQL de Inserção (8 campos)
            String sql = "INSERT INTO usuarios (nome, cpf, telefone, email, rua, numero, bairro, senha) VALUES (?,?,?,?,?,?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nome);
            ps.setString(2, cpf);
            ps.setString(3, telefone);
            ps.setString(4, email);
            ps.setString(5, rua);
            ps.setString(6, numero);
            ps.setString(7, bairro);
            ps.setString(8, senha); // No futuro, aplique criptografia aqui

            ps.executeUpdate();
            conn.close();

            // Redireciona para a página com o modal de sucesso
            response.sendRedirect("JSP/CadastrarUsuario.jsp?msg=sucesso");

        } catch (Exception e) {
            e.printStackTrace();
            // Redireciona para a página com o modal de erro (ex: CPF ou Email duplicado)
            response.sendRedirect("JSP/CadastrarUsuario.jsp?msg=erro");
        }
    }
}