/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Produto {
    private int id;
    private String nome;
    private double preco;
    private String categoria;
    private String imagemCaminho;

    // Construtor vazio
    public Produto() {}

    // Construtor com dados
    public Produto(int id, String nome, double preco, String categoria, String imagemCaminho) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.categoria = categoria;
        this.imagemCaminho = imagemCaminho;
    }

    // Getters e Setters (essenciais para o Java Web acessar os dados)
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }
    
    // ... adicione os outros getters e setters aqui
}