package controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/InserirProdutoServlet")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class InserirProdutoServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            // 1. Captura os dados (Atenção aos nomes dos parâmetros)
            String nome = request.getParameter("nome");
            String tipo = request.getParameter("tipoProduto");
            String subtipo = request.getParameter("subtipo"); // PEGANDO O SUBTIPO
            String marca = request.getParameter("marca");
            double preco = Double.parseDouble(request.getParameter("preco"));
            double valorMedida = Double.parseDouble(request.getParameter("valorMedida"));
            String unidadeMedida = request.getParameter("unidadeMedida");
            int estoque = Integer.parseInt(request.getParameter("estoque"));
            String descricao = request.getParameter("descricao");
            boolean destaque = request.getParameter("destaque") != null;

            // 2. Processa a Imagem
            Part filePart = request.getPart("imagem");
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String uploadPath = getServletContext().getRealPath("") + File.separator + "images";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();
            filePart.write(uploadPath + File.separator + fileName);

            // 3. Conexão e Inserção (SQL atualizado com 11 colunas)
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");
            
            // ORDEM: 1.nome, 2.tipo, 3.subtipo, 4.marca, 5.preco, 6.valor_medida, 7.unidade, 8.estoque, 9.descricao, 10.imagem, 11.destaque
            String sql = "INSERT INTO produtos (nome, tipo_produto, subtipo, marca, preco, valor_medida, unidade_medida, estoque, descricao, imagem, destaque) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nome);
            ps.setString(2, tipo);
            ps.setString(3, subtipo); // Antes o Java pulava isso e jogava a marca aqui
            ps.setString(4, marca);
            ps.setDouble(5, preco);   // Agora o preço cai na coluna de preço
            ps.setDouble(6, valorMedida);
            ps.setString(7, unidadeMedida);
            ps.setInt(8, estoque);
            ps.setString(9, descricao);
            ps.setString(10, fileName);
            ps.setBoolean(11, destaque);
            
            ps.executeUpdate();
            conn.close();

            // Ajustei o nome do seu JSP aqui (vi que no erro você escreveu CadastraProduto sem o 'r')
            response.sendRedirect("JSP/CadastrarProduto.jsp?msg=sucesso");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("JSP/CadastrarProduto.jsp?msg=erro");
        }
    }
}