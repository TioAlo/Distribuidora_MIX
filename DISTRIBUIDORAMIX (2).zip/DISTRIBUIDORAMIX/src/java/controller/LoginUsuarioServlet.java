package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginUsuarioServlet")
public class LoginUsuarioServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");

            // A query agora busca tudo, incluindo a nova coluna 'perfil'
            String sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, senha);

            rs = ps.executeQuery();

            if (rs.next()) {
                // Captura os dados do banco
                String nomeUsuario = rs.getString("nome");
                String emailUsuario = rs.getString("email");
                String perfilUsuario = rs.getString("perfil"); // CAPTURA O PERFIL (admin ou cliente)

                // Inicia a Sessão
                HttpSession session = request.getSession();
                session.setAttribute("usuarioLogado", nomeUsuario);
                session.setAttribute("emailLogado", emailUsuario);
                session.setAttribute("perfilLogado", perfilUsuario); // GUARDA O PERFIL NA SESSÃO

                // REDIRECIONAMENTO BASEADO NO PERFIL DO BANCO
                if ("Admin".equals(perfilUsuario)) {
                    response.sendRedirect("JSP/AdminHome.jsp");
                } else {
                    response.sendRedirect("Index.jsp");
                }

            } else {
                response.sendRedirect("JSP/Login.jsp?erro=1");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("JSP/Login.jsp?erro=1");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}