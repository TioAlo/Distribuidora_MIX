package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RecuperarSenhaServlet")
public class RecuperarSenhaServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/distribuidora_mix", "root", "root");

            // Verifica se o e-mail existe
            String sql = "SELECT id FROM usuarios WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Aqui entraria a lógica de enviar o e-mail (JavaMail API)
                // Por enquanto, apenas confirmamos o sucesso
                response.sendRedirect("JSP/EsqueciSenha.jsp?msg=sucesso");
            } else {
                // Mesmo que não exista, por segurança, costuma-se mostrar sucesso 
                // para evitar que "hackers" descubram quais e-mails estão cadastrados.
                response.sendRedirect("JSP/EsqueciSenha.jsp?msg=sucesso");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("JSP/EsqueciSenha.jsp?msg=erro");
        }
    }
}