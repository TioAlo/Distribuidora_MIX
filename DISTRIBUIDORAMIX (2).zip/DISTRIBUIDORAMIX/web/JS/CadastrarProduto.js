/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


let db = {
    "bebidas": {
        "agua": ["Minalba", "Indaiá"],
        "cerveja": ["Brahma", "Skol", "Heineken"]
    },
    "confeitaria": {
        "chocolates": ["Nestlé", "Lacta"]
    }
};

let nivelParaAdicionar = "";

document.addEventListener("DOMContentLoaded", () => {
    popularDepto();
});

function popularDepto() {
    const sel = document.getElementById("tipoProduto");
    const valAnterior = sel.value;
    sel.innerHTML = '<option value="">Selecione...</option>';
    Object.keys(db).forEach(depto => {
        sel.add(new Option(depto.toUpperCase(), depto));
    });
    if(valAnterior) sel.value = valAnterior;
}

function atualizarCategorias() {
    const depto = document.getElementById("tipoProduto").value;
    const sel = document.getElementById("subtipo");
    sel.innerHTML = '<option value="">Selecione Categoria...</option>';
    sel.disabled = !depto;

    if (depto && db[depto]) {
        Object.keys(db[depto]).forEach(cat => {
            sel.add(new Option(cat.toUpperCase(), cat));
        });
    }
    atualizarMarcas();
}

function atualizarMarcas() {
    const depto = document.getElementById("tipoProduto").value;
    const cat = document.getElementById("subtipo").value;
    const sel = document.getElementById("marca");
    sel.innerHTML = '<option value="">Selecione Marca...</option>';
    sel.disabled = !cat;

    if (cat && db[depto][cat]) {
        db[depto][cat].forEach(m => {
            sel.add(new Option(m, m));
        });
    }
    updateProgress();
}

// Funções do Modal
function abrirModal(nivel) {
    nivelParaAdicionar = nivel;
    document.getElementById("modalTitle").innerText = "Adicionar " + nivel.charAt(0).toUpperCase() + nivel.slice(1);
    document.getElementById("modalInput").value = "";
    document.getElementById("modalAdd").classList.add("active");
}

function fecharModal() {
    document.getElementById("modalAdd").classList.remove("active");
}

function confirmarAdicao() {
    const nome = document.getElementById("modalInput").value.trim().toLowerCase();
    if (!nome) return;

    const deptoAtu = document.getElementById("tipoProduto").value;
    const catAtu = document.getElementById("subtipo").value;

    if (nivelParaAdicionar === 'departamento') {
        if (!db[nome]) db[nome] = {};
        popularDepto();
    } else if (nivelParaAdicionar === 'categoria') {
        if (!deptoAtu) return alert("Selecione um Departamento!");
        db[deptoAtu][nome] = [];
        atualizarCategorias();
    } else if (nivelParaAdicionar === 'marca') {
        if (!catAtu) return alert("Selecione uma Categoria!");
        db[deptoAtu][catAtu].push(nome);
        atualizarMarcas();
    }
    fecharModal();
}

function gerarPreview(event) {
    const reader = new FileReader();
    reader.onload = () => {
        const out = document.getElementById('img-preview');
        out.src = reader.result;
        out.style.display = 'block';
        document.getElementById('upload-placeholder').style.display = 'none';
    };
    if(event.target.files[0]) reader.readAsDataURL(event.target.files[0]);
}

function updateProgress() {
    const reqs = document.querySelectorAll('input[required], select[required]');
    let filled = 0;
    reqs.forEach(r => { if (r.value) filled++; });
    document.getElementById("progressBar").style.width = (filled / reqs.length * 100) + "%";
}