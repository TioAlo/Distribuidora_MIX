// Funções de Máscara
function maskCPF(i) {
    let v = i.value;
    if (isNaN(v[v.length - 1])) { i.value = v.substring(0, v.length - 1); return; }
    i.setAttribute("maxlength", "14");
    if (v.length == 3 || v.length == 7) i.value += ".";
    if (v.length == 11) i.value += "-";
}

function maskPhone(i) {
    let v = i.value.replace(/\D/g, "");
    v = v.replace(/^(\2d)(\d)/g, "($1) $2");
    v = v.replace(/(\d)(\d{4})$/, "$1-$2");
    i.value = v;
}

// Barra de Progresso
function updateProgress() {
    const inputs = document.querySelectorAll('#formCadastro input[required]');
    let filled = 0;
    inputs.forEach(i => { if (i.value.trim() !== "") filled++; });
    const progress = (filled / inputs.length) * 100;
    document.getElementById("progressBar").style.width = progress + "%";
}

// Validação de Senha antes do envio
document.getElementById('formCadastro').onsubmit = function(e) {
    const senha = document.getElementById('senha').value;
    const confirma = document.getElementById('confirmar_senha').value;

    if (senha !== confirma) {
        alert("As senhas não coincidem!");
        return false;
    }
    return true;
};