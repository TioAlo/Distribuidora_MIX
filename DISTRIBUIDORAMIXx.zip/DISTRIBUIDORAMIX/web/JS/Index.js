/**
 * PROJETO: Distribuidora Mix
 * ARQUIVO: JavaScript.js
 * DESCRIÇÃO: Controle de filtros em cascata, ordenação via URL e animação do carrossel.
 */

// ==========================================================================
// 1. INICIALIZAÇÃO
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
    // Inicialização do carrossel
    initCarousel();
});

// ==========================================================================
// 2. LÓGICA DE FILTROS (CASCATA E URL)
// ==========================================================================

/**
 * Filtra os produtos recarregando a página com parâmetros na URL
 */
function filterBy(nivel, valor) {
    const url = new URL(window.location.href);
    if (nivel === 'todos') {
        url.searchParams.delete('nivel');
        url.searchParams.delete('valor');
    } else {
        url.searchParams.set('nivel', nivel);
        url.searchParams.set('valor', valor);
    }
    window.location.href = url.toString();
}

/**
 * Ordena os produtos (Preço, Nome, etc) via Query String
 */
function sortBy(ordem) {
    const url = new URL(window.location.href);
    if (ordem) {
        url.searchParams.set('ordem', ordem);
    } else {
        url.searchParams.delete('ordem');
    }
    window.location.href = url.toString();
}

/**
 * Expande/Recolhe os subníveis do menu lateral (Tipo > Subtipo > Marca)
 */
function toggleFilter(btn) {
    // O submenu é o próximo elemento irmão do contêiner do botão
    const parentHeader = btn.parentElement;
    const submenu = parentHeader.nextElementSibling;
    
    if (submenu && submenu.classList.contains('submenu')) {
        submenu.classList.toggle('active');
        // Altera o ícone visual entre '>' e 'v'
        btn.textContent = submenu.classList.contains('active') ? 'v' : '>';
        
        // Adiciona classe ao pai para controle de rotação via CSS (opcional)
        parentHeader.parentElement.classList.toggle('active');
    }
}

// ==========================================================================
// 3. LÓGICA DO CARROSSEL (AUTO-SCROLL)
// ==========================================================================
function initCarousel() {
    const track = document.querySelector('.carousel-track');
    let isPaused = false;

    if (track) {
        setInterval(() => {
            if (!isPaused) {
                track.scrollLeft += 1;
                // Reinicia o scroll ao chegar no fim
                if (track.scrollLeft >= (track.scrollWidth - track.clientWidth)) {
                    track.scrollLeft = 0;
                }
            }
        }, 30);

        // Pausa ao passar o mouse
        track.addEventListener('mouseenter', () => isPaused = true);
        track.addEventListener('mouseleave', () => isPaused = false);
    }
}

// ==========================================================================
// 4. MODAL DE QUANTIDADE (INTERFACE SIMPLES)
// ==========================================================================
// Nota: Se você removeu o carrinho, estas funções podem ser mantidas 
// apenas se você ainda pretende usar o modal para outra ação futura.

let tempProduct = {}; 

function openModal(nome, preco, id) {
    tempProduct = { nome, preco, id };
    const nameElem = document.getElementById('modal-product-name');
    const modalElem = document.getElementById('modal-qty');
    
    if (nameElem && modalElem) {
        nameElem.innerText = nome;
        modalElem.style.display = 'flex';
    }
}

function closeModal() {
    const modalElem = document.getElementById('modal-qty');
    if (modalElem) {
        modalElem.style.display = 'none';
        document.getElementById('input-qty').value = 1;
    }
}