/**
 * ARQUIVO: JavaScript.js
 * FUNÇÕES: Menu Mobile, Filtro em Cascata em 3 níveis, Carrinho e Modal
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // 1. MENU MOBILE
    const mobileMenu = document.getElementById('mobile-menu');
    const navLinks = document.querySelector('.nav-links');
    if (mobileMenu && navLinks) {
        mobileMenu.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            mobileMenu.classList.toggle('is-active');
        });
    }

    // 2. MÁSCARAS (CPF/TELEFONE)
    const cpfInput = document.getElementById('cpf');
    const telInput = document.getElementById('telefone');
    if (cpfInput) {
        cpfInput.addEventListener('input', (e) => {
            let v = e.target.value.replace(/\D/g, ''); 
            v = v.replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d{1,2})$/, "$1-$2");
            e.target.value = v.slice(0, 14);
        });
    }
    if (telInput) {
        telInput.addEventListener('input', (e) => {
            let v = e.target.value.replace(/\D/g, '');
            v = v.replace(/^(\d{2})(\d)/g, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
            e.target.value = v.slice(0, 15);
        });
    }

    // 3. INICIALIZAR CARRINHO
    updateCartCount();

    const btnConfirmAdd = document.getElementById('btn-confirm-add');
    if(btnConfirmAdd) {
        btnConfirmAdd.addEventListener('click', () => {
            const qtd = parseInt(document.getElementById('input-qty').value);
            if (qtd > 0) {
                addToCart(tempProduct.id, tempProduct.nome, tempProduct.preco, qtd);
                closeModal();
            }
        });
    }
});

// --- LÓGICA DE FILTRO EM CASCATA ---
function toggleFilter(btn) {
    // Evita que o clique no botão ative o link de filtro do texto ao lado
    if (window.event) window.event.stopPropagation(); 
    
    // Pega o li pai (seja da categoria ou do subtipo)
    const parentLi = btn.closest('li');
    
    // Alterna a classe active
    parentLi.classList.toggle('active');
    
    // Muda o ícone
    btn.innerText = parentLi.classList.contains('active') ? 'v' : '>';
}

function filterBy(nivel, valor) {
    if (nivel === 'todos') {
        window.location.href = "Index.jsp#catalogo";
        return;
    }
    const urlParams = new URLSearchParams(window.location.search);
    const ordem = urlParams.get('ordem');
    let novaUrl = "Index.jsp?nivel=" + nivel + "&valor=" + encodeURIComponent(valor);
    if (ordem) novaUrl += "&ordem=" + ordem;
    window.location.href = novaUrl + "#catalogo";
}

function sortBy(ordemValor) {
    const urlParams = new URLSearchParams(window.location.search);
    const nivel = urlParams.get('nivel');
    const valor = urlParams.get('valor');
    let novaUrl = "Index.jsp?";
    if (nivel && valor) novaUrl += "nivel=" + nivel + "&valor=" + encodeURIComponent(valor) + "&";
    if (ordemValor) novaUrl += "ordem=" + ordemValor;
    window.location.href = novaUrl + "#catalogo";
}

// --- LÓGICA DO CARRINHO ---
let tempProduct = {};
function openModal(nome, preco, id) {
    tempProduct = { nome, preco, id };
    document.getElementById('modal-product-name').innerText = nome;
    document.getElementById('modal-qty').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal-qty').style.display = 'none';
    document.getElementById('input-qty').value = 1;
}

function addToCart(id, nome, preco, qtd) {
    let cart = JSON.parse(localStorage.getItem('carrinho')) || [];
    const index = cart.findIndex(item => item.id === id);
    if (index > -1) cart[index].qtd += qtd;
    else cart.push({ id, nome, preco, qtd });
    localStorage.setItem('carrinho', JSON.stringify(cart));
    updateCartCount();
    alert(nome + " adicionado!");
}

function updateCartCount() {
    const el = document.getElementById('cart-count');
    if (el) {
        let cart = JSON.parse(localStorage.getItem('carrinho')) || [];
        const total = cart.reduce((acc, item) => acc + item.qtd, 0);
        el.innerText = total;
        el.style.display = total > 0 ? 'flex' : 'none';
    }
}
// ------------------- 5. ADMIN (PREVIEW DE PRODUTO) -------------------

function gerarPreview(event) {
    const file = event.target.files[0];
    const output = document.getElementById('img-preview');
    const placeholder = document.getElementById('upload-placeholder');

    if (file) {
        const reader = new FileReader();
        reader.onload = function () {
            if (output) {
                output.src = reader.result;
                output.style.display = 'block';
                if (placeholder) placeholder.style.display = 'none';
            }
        };
        reader.readAsDataURL(file);
    }
}